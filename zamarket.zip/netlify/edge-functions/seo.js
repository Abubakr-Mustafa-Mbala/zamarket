// Crawlable metadata and initial, truthful page content for JS and non-JS clients.
// Never publish privileged data or replace search output with unrelated keywords.
const SITE = 'https://zamarket.shop'
const SHOP = 'ZaMarket'

const esc = value => String(value ?? '')
  .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
  .replace(/"/g, '&quot;').replace(/'/g, '&#39;').replace(/\s+/g, ' ').trim()
const clip = (s, n = 155) => {
  const t = String(s ?? '').replace(/\s+/g, ' ').trim()
  return t.length > n ? `${t.slice(0, n - 1).trimEnd()}…` : t
}
const money = v => `K${Number(v).toLocaleString('en-ZM', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`

// Include every public route here so informational pages don't get mistaken for
// unknown vendors (and incorrectly tagged noindex).
const RESERVED = new Set([
  'p', 'search', 'sellers', 'store', 'cart', 'checkout', 'order', 'rate', 'review',
  'login', 'reset-password', 'recover', 'account', 'apply', 'affiliates', 'blog', 'admin', 'sell', 'vendor', 'go', 'r', 'v',
  'free', 'invite', 'saved', 'categories', 'about', 'how-it-works', 'protection',
  'giveaways', 'motors',
  'assets', 'favicon.ico', 'robots.txt', 'sitemap.xml',
])
const PRIVATE = new Set(['admin', 'sell', 'vendor', 'cart', 'checkout', 'account', 'login', 'reset-password', 'recover', 'order', 'rate', 'invite', 'go', 'r', 'v', 'review', 'saved'])

async function getOne(path, base, key) {
  try {
    const response = await fetch(`${base}/rest/v1/${path}`, {
      headers: { apikey: key, authorization: `Bearer ${key}` },
      signal: AbortSignal.timeout(5000),
    })
    if (!response.ok) return { ok: false, item: null }
    const data = await response.json()
    return { ok: true, item: Array.isArray(data) ? data[0] || null : data }
  } catch { return { ok: false, item: null } }
}

// Schema.org has named types for the trades most of our sellers are in, and a
// named type gives Google more to work with than a generic shop when someone
// searches for "someone who bakes in Lusaka". Only mapped where the category
// makes the trade unambiguous; anything else stays a Store, because claiming
// a business is a bakery when it is not is worse than saying nothing.
const BUSINESS_TYPES = [
  [/bakery|cake|pastry|bread|confection/i, 'Bakery'],
  [/restaurant|takeaway|kitchen|caterer|catering|food/i, 'FoodEstablishment'],
  [/salon|hair|nail|beauty|spa|barber|braid/i, 'HealthAndBeautyBusiness'],
  [/cloth|fashion|tailor|boutique|apparel|wear/i, 'ClothingStore'],
  [/shoe|footwear/i, 'ShoeStore'],
  [/phone|electronic|computer|laptop|gadget/i, 'ElectronicsStore'],
  [/furniture/i, 'FurnitureStore'],
  [/home|decor|interior|household/i, 'HomeGoodsStore'],
  [/garden|nursery|plant/i, 'GardenStore'],
  [/car|motor|vehicle|auto.?repair|mechanic/i, 'AutoRepair'],
  [/florist|flower/i, 'Florist'],
  [/jewel/i, 'JewelryStore'],
  [/driving school|driving lesson/i, 'DrivingSchool'],
  [/school|tuition|college|training|course/i, 'EducationalOrganization'],
  [/photograph|photo studio/i, 'PhotographAction'],
]
const businessType = category => {
  const c = String(category || '')
  for (const [match, type] of BUSINESS_TYPES) if (match.test(c)) return type
  return 'Store'
}

// Sellers type their hours as free text — "Mon-Fri: 8am - 6pm" — which cannot
// be turned into schema.org's strict format without guessing, and a guessed
// opening time sends a customer to a closed door. So the hours are not put in
// the structured data at all; they go into the page text below instead, where
// they are just as findable and cannot be misread as a machine-readable fact.
const hoursText = value => (Array.isArray(value) ? value : [])
  .filter(x => x && x.label && x.hours)
  .map(x => `${String(x.label).trim()}: ${String(x.hours).trim()}`)
  .slice(0, 7)

const paragraph = t => `<p>${esc(clip(t, 4500))}</p>`
const fallback = (heading, description, link = '') => `<main class="seo-fallback"><h1>${esc(heading)}</h1>${paragraph(description)}${link ? `<p><a href="${esc(link)}">View the full page</a></p>` : ''}</main>`

// schema.org availability from the product's actual state. Returns undefined
// when it cannot be known, so nothing is claimed rather than guessed.
export function availabilityOf(p) {
  if (!p) return undefined
  if (p.fulfilment === 'service') return undefined
  if (p.fulfilment === 'made_to_order') return 'https://schema.org/MadeToOrder'
  if (p.status === 'out_of_stock') return 'https://schema.org/OutOfStock'
  const stock = Number(p.stock_available)
  if (Number.isFinite(stock)) return stock > 0 ? 'https://schema.org/InStock' : 'https://schema.org/OutOfStock'
  return undefined
}

export default async function handler(request, context) {
  const response = await context.next()
  if (!(response.headers.get('content-type') || '').includes('text/html')) return response

  const current = new URL(request.url)
  const parts = current.pathname.split('/').filter(Boolean)
  const base = Deno.env.get('VITE_SUPABASE_URL')
  const key = Deno.env.get('VITE_SUPABASE_ANON_KEY')
  let canonical = SITE + (current.pathname === '/' ? '/' : current.pathname.replace(/\/$/, ''))
  let title = `${SHOP} — Shop online in Lusaka, Zambia`
  let description = 'Browse products from local sellers in Lusaka, Zambia. Compare prices and order phones, fashion, home essentials, food and more on ZaMarket.'
  let image = `${SITE}/social.png`
  let robots = parts.length && (PRIVATE.has(parts[0]) || parts[0] === 'search') ? 'noindex,follow' : 'index,follow'
  let schema = null
  let initialContent = ''

  if (!parts.length) {
    schema = {
      '@context': 'https://schema.org', '@type': 'OnlineStore', name: SHOP,
      url: `${SITE}/`, description, areaServed: { '@type': 'City', name: 'Lusaka' },
    }
    initialContent = fallback('Shop products from local sellers in Lusaka', description, `${SITE}/sellers`)
  } else if (parts[0] === 'blog') {
    if (parts.length === 1) {
      title = `ZaMarket Journal — Local stories, guides and discoveries | ${SHOP}`
      description = 'Discover local Zambian businesses, practical buying guides, and products worth exploring in the ZaMarket Journal.'
      canonical = `${SITE}/blog`
      initialContent = fallback('Stories, guides and discoveries worth exploring', description, `${SITE}/blog`)
    } else if (parts.length === 2 && base && key) {
      const result = await getOne(`public_posts?slug=eq.${encodeURIComponent(parts[1])}&select=slug,title,excerpt,body,cover_url,meta_title,meta_description,author,published_at`, base, key)
      if (result.ok && !result.item) robots = 'noindex,follow'
      if (result.item) {
        const post = result.item
        canonical = `${SITE}/blog/${encodeURIComponent(post.slug)}`
        title = post.meta_title || `${post.title} | ${SHOP}`
        description = clip(post.meta_description || post.excerpt || post.body, 155)
        if (typeof post.cover_url === 'string' && /^https:\/\//i.test(post.cover_url)) image = post.cover_url
        schema = {
          '@context': 'https://schema.org', '@type': 'Article', headline: post.title,
          description, mainEntityOfPage: canonical,
          author: { '@type': 'Organization', name: post.author || SHOP },
          publisher: { '@type': 'Organization', name: SHOP },
          datePublished: post.published_at || undefined,
          image: image !== `${SITE}/social.png` ? image : undefined,
        }
        // Initial HTML is visible to all visitors, not just crawlers. React
        // replaces this fallback when JS starts; content stays consistent.
        const plainBody = String(post.body || '').replace(/!\[([^\]]*)\]\([^)]+\)/g, '$1')
          .replace(/\[video\]\([^)]+\)/gi, 'Video included in the article.')
          .replace(/\[([^\]]+)\]\([^)]+\)/g, '$1')
          .replace(/[#*`>]/g, '').replace(/\n+/g, ' ')
        initialContent = fallback(post.title, plainBody || post.excerpt || '', canonical)
      }
    }
  } else if (parts[0] === 'r' && parts.length === 3 && base && key) {
    // WhatsApp/Facebook preview robots do not execute React redirects. Give
    // affiliate URLs the same actual product picture and description as the
    // public product, while leaving the URL intact so clicks retain credit.
    const slug = parts[2]
    const { item: p } = await getOne(`public_products?slug=eq.${encodeURIComponent(slug)}&select=name,description,price,images,slug,vendor_name`, base, key)
    if (p) {
      title = `${p.name}${Number.isFinite(Number(p.price)) ? ` — ${money(p.price)}` : ''} | ${SHOP}`
      description = clip(p.description || `View ${p.name} on ZaMarket from ${p.vendor_name || 'a local seller'}.`)
      const first = (p.images || []).find(x => typeof x === 'string' && /^https:\/\//i.test(x))
      if (first) image = first
      canonical = `${SITE}/p/${encodeURIComponent(slug)}`
      initialContent = fallback(p.name, description, `${SITE}/r/${encodeURIComponent(parts[1])}/${encodeURIComponent(slug)}`)
    }
  } else if (parts[0] === 'motors') {
    title = `Cars and vehicles for sale in Zambia | ZaMarket Motors`
    description = 'Explore real car listings from sellers across Zambia, compare photographs and specifications, and enquire about a vehicle on ZaMarket Motors.'
    canonical = `${SITE}/motors`
    initialContent = fallback('ZaMarket Motors', description, `${SITE}/motors`)
  } else if (parts[0] === 'search') {
    canonical = `${SITE}/search`
  } else if (parts[0] === 'sellers') {
    title = `Local sellers and shops in Lusaka | ${SHOP}`
    description = 'Find and compare local shops and sellers on ZaMarket in Lusaka, Zambia.'
    initialContent = fallback('Explore local sellers in Lusaka', description, `${SITE}/sellers`)
  } else if (parts[0] === 'affiliates') {
    title = 'Become a ZaMarket Affiliate in Zambia | Apply & Learn'
    description = 'Join the ZaMarket affiliate programme in Zambia. Learn to promote products and earn commission on qualifying completed sales. No salary or guaranteed earnings.'
    canonical = `${SITE}/affiliates`
    initialContent = fallback('Become a ZaMarket Affiliate in Zambia', description, `${SITE}/affiliates`)
  } else if (parts[0] === 'apply' && parts[1] === 'vendor') {
    title = `Sell your products on ZaMarket | Join as a vendor`
    description = 'Apply to sell through ZaMarket, a local online marketplace connecting businesses and shoppers in Zambia.'
    initialContent = fallback('Become a ZaMarket vendor', description, `${SITE}/apply/vendor`)
  } else if (parts[0] === 'apply' && parts[1] === 'reseller') {
    title = `Earn by promoting ZaMarket products | Become a reseller`
    description = 'Learn how to apply as a ZaMarket reseller and promote local products to potential customers in Zambia.'
    initialContent = fallback('Apply as a ZaMarket reseller', description, `${SITE}/apply/reseller`)
  } else if (parts[0] === 'how-it-works') {
    title = `How buying on ZaMarket works | ${SHOP}`
    description = 'Learn how to find products, order and arrange delivery through ZaMarket in Lusaka.'
  } else if (parts[0] === 'about') {
    title = `About ZaMarket — Local marketplace in Zambia`
    description = 'Learn more about ZaMarket, the marketplace connecting customers with local sellers in Zambia.'
  } else if (parts[0] === 'categories') {
    title = `Shop product categories in Lusaka | ${SHOP}`
  } else if (parts[0] === 'protection') {
    title = `Customer protection and buying safely | ${SHOP}`
  } else if (parts[0] === 'giveaways') {
    // Entry is free and no purchase is required, so the copy must not imply
    // that buying improves anyone's chances.
    title = `Giveaways | ${SHOP}`
    description = 'Free-to-enter giveaways from local sellers on ZaMarket. No purchase necessary. Winners are drawn at random and announced publicly.'
    canonical = parts.length === 2 ? `${SITE}/giveaways/${parts[1]}` : `${SITE}/giveaways`
  }

  if (base && key && parts[0] !== 'blog' && parts[0] !== 'search') {
    const productSlug = parts[0] === 'p' && parts.length === 2 ? parts[1]
      : parts.length === 2 && !RESERVED.has(parts[0]) ? parts[1] : null
    const vendorSlug = parts[0] === 'store' && parts.length === 2 ? parts[1]
      : parts.length === 1 && !RESERVED.has(parts[0]) ? parts[0] : null

    if (productSlug) {
      const { ok, item: p } = await getOne(`public_products?slug=eq.${encodeURIComponent(productSlug)}&select=name,description,price,images,category,vendor_name,rating,review_count,fulfilment,offering_type,page,slug,vendor_slug,status,stock_available`, base, key)
      // A temporary Supabase failure MUST NOT mark all catalogue pages noindex.
      if (ok && !p) robots = 'noindex,follow'
      if (p) {
        canonical = p.vendor_slug ? `${SITE}/${p.vendor_slug}/${p.slug}` : `${SITE}/p/${p.slug}`
        title = p.page?.seo?.title || `${p.name}${Number.isFinite(Number(p.price)) ? ` — ${money(p.price)}` : ''} | ${SHOP}`
        description = clip(p.page?.seo?.description || p.description || `${p.name} on ZaMarket, Lusaka, Zambia.`)
        if (typeof p.images?.[0] === 'string' && /^https:\/\//i.test(p.images[0])) image = p.images[0]
        schema = {
          '@context': 'https://schema.org', '@type': 'Product', name: p.name,
          description: clip(p.description || p.name, 300),
          image: (p.images || []).filter(x => typeof x === 'string' && /^https:\/\//i.test(x)),
          category: p.category || undefined,
          brand: p.vendor_name ? { '@type': 'Brand', name: p.vendor_name } : undefined,
          offers: Number.isFinite(Number(p.price)) && Number(p.price) >= 0
            ? {
                '@type': 'Offer', url: canonical, price: Number(p.price), priceCurrency: 'ZMW',
                // What Google prints beside the price. It is read from the
                // product's real state, never assumed: claiming "in stock"
                // for something that is not gets a listing demoted.
                availability: availabilityOf(p),
                itemCondition: 'https://schema.org/NewCondition',
                seller: { '@type': 'Organization', name: p.vendor_name || SHOP },
              }
            : undefined,
          aggregateRating: Number(p.rating) > 0 && Number(p.review_count) > 0
            ? { '@type': 'AggregateRating', ratingValue: p.rating, reviewCount: p.review_count }
            : undefined,
        }
        initialContent = fallback(p.name, p.description || `${p.name} available from ${p.vendor_name || 'a local seller'} on ZaMarket.`, canonical)
      }
    } else if (vendorSlug) {
      const { ok, item: v } = await getOne(`public_vendors?slug=eq.${encodeURIComponent(vendorSlug)}&select=business_name,description,about,tagline,category,town,rating,review_count,slug,logo_url,cover_url,opening_hours`, base, key)
      if (ok && !v) robots = 'noindex,follow'
      if (v) {
        canonical = `${SITE}/${v.slug}`
        title = `${v.business_name}${v.town ? ` — ${v.town}` : ''} | ${SHOP}`
        description = clip(v.description || v.tagline || v.about || `Order from ${v.business_name} on ZaMarket.`)
        // The seller's own picture, so sharing a shop link shows THEIR shop
        // and not our logo. Their cover first, then their mark; the generic
        // ZaMarket image only when they have uploaded neither.
        const vendorPic = [v.cover_url, v.logo_url].find(x => typeof x === 'string' && /^https:\/\//i.test(x))
        if (vendorPic) image = vendorPic
        // A more specific business type than "Store", so a search for someone
        // who bakes can match a bakery rather than a generic shop. Falls back
        // to Store when the trade is not one we can name confidently — a
        // wrong type is worse than a general one.
        schema = {
          '@context': 'https://schema.org', '@type': businessType(v.category),
          name: v.business_name, url: canonical, description,
          image: vendorPic || undefined,
          address: { '@type': 'PostalAddress', addressLocality: v.town || 'Lusaka', addressCountry: 'ZM' },
          areaServed: { '@type': 'City', name: v.town || 'Lusaka' },
          aggregateRating: Number(v.rating) > 0 && Number(v.review_count) > 0
            ? { '@type': 'AggregateRating', ratingValue: v.rating, reviewCount: v.review_count } : undefined,
        }
        // What a crawler sees before any JavaScript runs. The trade, the
        // area and the hours in plain words, because that is what someone
        // searching "who bakes cakes in Kabwata" is actually matching.
        const hrs = hoursText(v.opening_hours)
        initialContent = fallback(v.business_name, description, canonical)
          .replace('</main>', `${v.category ? paragraph(`${v.business_name} is a ${String(v.category).toLowerCase()} business${v.town ? ` in ${v.town}` : ''}, Zambia, selling on ZaMarket.`) : ''}${hrs.length ? `<p>Opening hours — ${esc(hrs.join('; '))}</p>` : ''}</main>`)
      }
    }
  }

  const ogType = schema?.['@type'] === 'Article' ? 'article' : schema?.['@type'] === 'Product' ? 'product' : 'website'
  const head = `
    <title>${esc(title)}</title>
    <meta name="description" content="${esc(description)}" />
    <meta name="robots" content="${robots}" />
    <link rel="canonical" href="${esc(canonical)}" />
    <meta property="og:type" content="${ogType}" />
    <meta property="og:site_name" content="${SHOP}" />
    <meta property="og:title" content="${esc(title)}" />
    <meta property="og:description" content="${esc(description)}" />
    <meta property="og:image" content="${esc(image)}" />
    <meta property="og:url" content="${esc(parts[0] === 'r' ? `${SITE}${current.pathname}` : canonical)}" />
    <meta property="og:locale" content="en_ZM" />
    <meta name="twitter:card" content="summary_large_image" />
    <meta name="twitter:title" content="${esc(title)}" />
    <meta name="twitter:description" content="${esc(description)}" />
    <meta name="twitter:image" content="${esc(image)}" />
    ${schema ? `<script type="application/ld+json" data-zm-edge-jsonld="true" data-zm-edge-path="${esc(current.pathname)}">${JSON.stringify(schema).replace(/</g, '\\u003c')}</script>` : ''}`

  let html = await response.text()
  html = html
    .replace(/<title>[^<]*<\/title>/gi, '')
    .replace(/<meta\s+name=["'](?:description|robots)["'][^>]*>/gi, '')
    .replace(/<link\s+rel=["']canonical["'][^>]*>/gi, '')
    .replace('</head>', `${head}</head>`)
  if (initialContent) html = html.replace('<div id="root"></div>', `<div id="root">${initialContent}</div>`)
  const headers = new Headers(response.headers)
  headers.delete('content-length')
  headers.delete('content-encoding')
  headers.set('content-type', 'text/html; charset=utf-8')
  headers.set('cache-control', 'public, max-age=120')
  return new Response(html, { status: response.status, headers })
}

export const config = { path: '/*', excludedPath: ['/assets/*', '/*.png', '/*.jpg', '/*.svg', '/*.ico', '/*.xml', '/*.txt'] }
